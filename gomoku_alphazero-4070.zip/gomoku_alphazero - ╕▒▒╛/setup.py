from setuptools import setup, find_packages

setup(
    name="gomoku_alphazero",
    version="0.1",
    packages=find_packages(),
)