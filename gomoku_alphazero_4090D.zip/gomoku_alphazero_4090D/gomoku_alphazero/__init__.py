# 删除原来的内容，改为：
from .config import Config

__all__ = ['Config']
__version__ = '0.1.0'